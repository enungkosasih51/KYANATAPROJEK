# KYANATA Android project

The `app/src/main/assets/site/` folder contains the 5.4 HTML/CSS/JS and image/audio assets. `ApiConfig.kt` is the native-side base URL configuration; `site/api-config.js` is the central configuration used by the bundled website files.

Website base URL: `http://paizeepanel.duckdns.top:4914`
API base URL: `http://paizeepanel.duckdns.top:4919`

`NEFLAX2026` is included only because it was requested for quick setup. A key embedded in APK/web JavaScript is visible to users and is not a real secret. HTTP is unencrypted.

Note: current MainActivity is still the existing native screen scaffold; bundling web assets does not automatically make it display those assets. A WebView integration and end-to-end API/session test are still required before treating this as a finished APK.
