/* Central API config for all bundled pages. Do not treat client-side keys as secrets. */
window.KYANATA_CONFIG = Object.freeze({
  API_BASE_URL: "http://paizeepanel.duckdns.top:4919",
  WEBSITE_BASE_URL: "http://paizeepanel.duckdns.top:4914",
  API_KEY: "NEFLAX2026"
});
