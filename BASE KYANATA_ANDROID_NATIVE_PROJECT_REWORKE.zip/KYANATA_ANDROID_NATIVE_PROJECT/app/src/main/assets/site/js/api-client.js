(function(){
  const cfg=window.KYANATA_CONFIG||{API_BASE_URL:"http://paizeepanel.duckdns.top:4919",API_KEY:"NEFLAX2026"};
  window.kyanataApi=async function(path, options={}){
    const url=cfg.API_BASE_URL+ (path.startsWith("/")?path:"/"+path);
    const headers={"Content-Type":"application/json","X-KYANATA-KEY":cfg.API_KEY,...(options.headers||{})};
    const response=await fetch(url,{...options,headers,credentials:"include"});
    const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new Error(data.error||data.message||("HTTP "+response.status));
    return data;
  };
})();
