package com.kyanata.app

object ApiConfig {
    const val WEBSITE_BASE_URL = "http://paizeepanel.duckdns.top:4914"
    const val API_BASE_URL = "http://paizeepanel.duckdns.top:4919"
    const val API_KEY = "NEFLAX2026"
}
